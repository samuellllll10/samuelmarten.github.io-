
import React, { useState } from 'react';
import type { GeneratedPayload } from '../../types';
import { Card, CardContent, CardHeader } from '../common/Card';
import { Spinner } from '../common/icons';

interface PayloadPanelProps {
  onGenerate: (vulnType: string, context: string) => Promise<void>;
  payloads: GeneratedPayload[] | null;
  isLoading: boolean;
  error: string | null;
}

const VULN_TYPES = ['XSS (Cross-Site Scripting)', 'SQLi (SQL Injection)', 'SSTI (Server-Side Template Injection)', 'LFI (Local File Inclusion)', 'SSRF (Server-Side Request Forgery)', 'RCE (Remote Code Execution)'];

const PayloadCard: React.FC<{ payload: GeneratedPayload }> = ({ payload }) => {
    const effectivenessColor = payload.effectiveness > 0.7 ? 'text-green-400' : payload.effectiveness > 0.4 ? 'text-yellow-400' : 'text-red-400';
    return (
        <Card className="mb-4 bg-gray-900/70">
            <CardHeader className="flex justify-between items-center">
                <h4 className="font-bold text-lg text-cyan-400">{payload.type}</h4>
                <div className="text-sm">
                    <span className="font-medium text-gray-400">Effectiveness: </span>
                    <span className={`font-bold ${effectivenessColor}`}>{Math.round(payload.effectiveness * 100)}%</span>
                </div>
            </CardHeader>
            <CardContent>
                <p className="text-gray-300 font-medium mb-2">Generated Payload:</p>
                <pre className="bg-black p-3 rounded-md text-green-300 font-mono text-sm whitespace-pre-wrap break-all">
                    <code>{payload.payload}</code>
                </pre>
                <p className="text-gray-300 font-medium mt-4 mb-2">Evolution Logic:</p>
                <p className="text-sm text-gray-400">{payload.description}</p>
            </CardContent>
        </Card>
    );
};

const PayloadPanel: React.FC<PayloadPanelProps> = ({ onGenerate, payloads, isLoading, error }) => {
  const [vulnType, setVulnType] = useState(VULN_TYPES[0]);
  const [context, setContext] = useState('<input type="text" name="q" value="USER_INPUT">');

  const handleGenerate = () => {
    onGenerate(vulnType, context);
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <h2 className="text-3xl font-bold text-white mb-2">AI Payload Generator (DNA Evolution)</h2>
      <p className="text-gray-400 mb-6">Create adaptive payloads that evolve based on target context.</p>

      <Card className="mb-6">
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-1">
              <label htmlFor="vulnType" className="block text-sm font-medium text-gray-300 mb-2">Vulnerability Type</label>
              <select
                id="vulnType"
                value={vulnType}
                onChange={(e) => setVulnType(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                disabled={isLoading}
              >
                {VULN_TYPES.map(v => <option key={v}>{v}</option>)}
              </select>
            </div>
            <div className="md:col-span-2">
              <label htmlFor="context" className="block text-sm font-medium text-gray-300 mb-2">Target Context (e.g., HTML snippet, parameter)</label>
              <textarea
                id="context"
                value={context}
                onChange={(e) => setContext(e.target.value)}
                rows={2}
                className="w-full bg-gray-800 border border-gray-700 rounded-md px-3 py-2 text-white font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                disabled={isLoading}
              />
            </div>
          </div>
          <div className="mt-4 text-right">
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800/50 disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-md transition-all flex items-center justify-center ml-auto"
            >
              {isLoading ? <Spinner className="w-5 h-5" /> : 'Generate Payloads'}
            </button>
          </div>
        </CardContent>
      </Card>

      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg mb-6">
            <p className="font-bold">Error</p>
            <p>{error}</p>
        </div>
      )}

      {isLoading && (
        <div className="text-center py-10">
            <Spinner className="w-12 h-12 mx-auto text-blue-500" />
            <p className="mt-4 text-gray-400">AI is evolving payloads...</p>
        </div>
      )}

      {payloads && payloads.length > 0 && (
        <div>
          {payloads.map((p, i) => <PayloadCard key={i} payload={p} />)}
        </div>
      )}

       {!isLoading && !payloads && (
         <div className="text-center py-10 border-2 border-dashed border-gray-700 rounded-lg">
            <p className="text-gray-500">Generated payloads will appear here.</p>
         </div>
      )}
    </div>
  );
};

export default PayloadPanel;
