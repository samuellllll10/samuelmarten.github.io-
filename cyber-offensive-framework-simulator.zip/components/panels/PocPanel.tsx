
import React from 'react';
import type { PocReport, ExploitChain, ReconResult } from '../../types';
import { Card, CardContent, CardHeader } from '../common/Card';
import { Spinner } from '../common/icons';

interface PocPanelProps {
  onGeneratePoc: () => Promise<void>;
  pocReport: PocReport | null;
  exploitChain: ExploitChain | null;
  reconResult: ReconResult | null;
  isLoading: boolean;
  error: string | null;
}

const PocPanel: React.FC<PocPanelProps> = ({ onGeneratePoc, pocReport, exploitChain, reconResult, isLoading, error }) => {
  const canGenerate = reconResult !== null && exploitChain !== null;

  return (
    <div className="p-8 h-full overflow-y-auto">
      <h2 className="text-3xl font-bold text-white mb-2">Auto PoC Generator</h2>
      <p className="text-gray-400 mb-6">Automatically create a detailed bug bounty report from findings.</p>

      <Card className="mb-6">
        <CardContent className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white">Generate HackerOne/Bugcrowd Report</h3>
            <p className="text-sm text-gray-400">
              {canGenerate ? 'Ready to generate from Recon & Exploit Chain data.' : 'Requires successful Recon and Exploit Chaining first.'}
            </p>
          </div>
          <button
            onClick={onGeneratePoc}
            disabled={isLoading || !canGenerate}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800/50 disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-md transition-all flex items-center justify-center"
          >
            {isLoading ? <Spinner className="w-5 h-5" /> : 'Generate Report'}
          </button>
        </CardContent>
      </Card>

      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg mb-6">
            <p className="font-bold">Error</p>
            <p>{error}</p>
        </div>
      )}

      {isLoading && (
        <div className="text-center py-10">
            <Spinner className="w-12 h-12 mx-auto text-blue-500" />
            <p className="mt-4 text-gray-400">AI is drafting the security report...</p>
        </div>
      )}

      {pocReport && (
        <Card>
          <CardHeader>
            <h3 className="text-xl font-bold text-cyan-300">{pocReport.title}</h3>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-300">
            <div>
              <h4 className="font-semibold text-lg text-white mb-2 border-b border-gray-700 pb-1">Summary</h4>
              <p className="text-sm">{pocReport.summary}</p>
            </div>
            <div>
              <h4 className="font-semibold text-lg text-white mb-2 border-b border-gray-700 pb-1">Impact</h4>
              <p className="text-sm">{pocReport.impact}</p>
            </div>
            <div>
              <h4 className="font-semibold text-lg text-white mb-2 border-b border-gray-700 pb-1">Steps to Reproduce</h4>
              <pre className="bg-gray-900 p-4 rounded-md text-sm whitespace-pre-wrap">{pocReport.steps_to_reproduce}</pre>
            </div>
            <div>
              <h4 className="font-semibold text-lg text-white mb-2 border-b border-gray-700 pb-1">PoC cURL Command</h4>
              <pre className="bg-black p-3 rounded-md text-green-300 font-mono text-sm whitespace-pre-wrap break-all">
                <code>{pocReport.curl_command}</code>
              </pre>
            </div>
            <div>
              <h4 className="font-semibold text-lg text-white mb-2 border-b border-gray-700 pb-1">Recommendation</h4>
              <p className="text-sm">{pocReport.recommendation}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {!isLoading && !pocReport && (
         <div className="text-center py-10 border-2 border-dashed border-gray-700 rounded-lg">
            <p className="text-gray-500">Generated PoC report will appear here.</p>
            {!canGenerate && <p className="text-yellow-500 text-sm mt-2">Please run Recon and Exploit Chaining first.</p>}
         </div>
      )}
    </div>
  );
};

export default PocPanel;
