
import React from 'react';
import { Card, CardContent, CardHeader } from '../common/Card';

const Toggle: React.FC<{ label: string; description: string; enabled: boolean }> = ({ label, description, enabled }) => (
  <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-md">
    <div>
      <p className="font-medium text-white">{label}</p>
      <p className="text-xs text-gray-400">{description}</p>
    </div>
    <div className={`w-14 h-8 flex items-center rounded-full p-1 cursor-pointer ${enabled ? 'bg-green-500' : 'bg-gray-700'}`}>
      <div className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${enabled ? 'translate-x-6' : ''}`}></div>
    </div>
  </div>
);

const StealthPanel: React.FC = () => {
  return (
    <div className="p-8 h-full overflow-y-auto">
      <h2 className="text-3xl font-bold text-white mb-2">Stealth Human-Like Interaction AI</h2>
      <p className="text-gray-400 mb-6">Simulated settings for evading WAF and anti-bot detection.</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <h3 className="text-xl font-semibold text-white">Behavioral Mimicry</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <Toggle label="Human-like Delays" description="Randomized delays between actions." enabled={true} />
            <Toggle label="Cursor Trajectory" description="Simulate realistic mouse movement paths." enabled={true} />
            <Toggle label="Scroll Emulation" description="Mimic natural scrolling behavior." enabled={true} />
            <Toggle label="Session Mimicking" description="Replicate typical user session lengths and patterns." enabled={false} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-xl font-semibold text-white">Fingerprint Evasion</h3>
          </CardHeader>
          <CardContent className="space-y-4">
            <Toggle label="User-Agent Rotation" description="Automatically cycle through real browser user-agents." enabled={true} />
            <Toggle label="Canvas Spoofing" description="Introduce noise to canvas fingerprinting." enabled={true} />
            <Toggle label="WebGL & Font Masking" description="Mask unique WebGL and font profiles." enabled={true} />
            <Toggle label="Timezone Jitter" description="Slightly alter timezone to match IP location." enabled={false} />
          </CardContent>
        </Card>
      </div>

      <div className="mt-8 p-4 bg-gray-800/50 rounded-lg text-center">
        <p className="font-semibold text-yellow-400">Simulation Notice</p>
        <p className="text-sm text-gray-400 mt-1">These settings are for visualization purposes only. No actual browser fingerprint modification is performed.</p>
      </div>
    </div>
  );
};

export default StealthPanel;
