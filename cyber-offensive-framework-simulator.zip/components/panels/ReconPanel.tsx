
import React, { useState } from 'react';
import type { ReconResult, ReconAsset } from '../../types';
import { Card, CardContent, CardHeader } from '../common/Card';
import { Spinner } from '../common/icons';

interface ReconPanelProps {
  onStartRecon: (target: string) => Promise<void>;
  reconResult: ReconResult | null;
  isLoading: boolean;
  error: string | null;
}

const AssetCard: React.FC<{ asset: ReconAsset }> = ({ asset }) => {
    const getIcon = (type: ReconAsset['type']) => {
        switch (type) {
            case 'Subdomain': return '🌐';
            case 'API Endpoint': return '🔌';
            case 'IP Address': return '💡';
            case 'JavaScript File': return '📜';
            default: return '📁';
        }
    }
    return (
        <div className="bg-gray-800/50 p-3 rounded-md border border-gray-700 hover:bg-gray-700/50 transition-colors">
            <div className="flex items-center">
                <span className="text-xl mr-3">{getIcon(asset.type)}</span>
                <div>
                    <p className="font-mono text-sm text-green-400">{asset.value}</p>
                    <p className="text-xs text-gray-400">{asset.type}</p>
                </div>
            </div>
             <p className="text-xs text-gray-500 mt-2 pl-8">{asset.description}</p>
        </div>
    );
};

const ReconPanel: React.FC<ReconPanelProps> = ({ onStartRecon, reconResult, isLoading, error }) => {
  const [target, setTarget] = useState('example.com');

  const handleStart = () => {
    if (target) {
      onStartRecon(target);
    }
  };

  return (
    <div className="p-8 h-full overflow-y-auto">
      <h2 className="text-3xl font-bold text-white mb-2">Adaptive Recon & Crawler</h2>
      <p className="text-gray-400 mb-6">Map digital assets from a domain, including hidden endpoints and subdomains.</p>
      
      <Card className="mb-6">
        <CardContent className="flex items-center space-x-4">
          <input
            type="text"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder="Enter target domain (e.g., example.com)"
            className="flex-grow bg-gray-800 border border-gray-700 rounded-md px-4 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            disabled={isLoading}
          />
          <button
            onClick={handleStart}
            disabled={isLoading || !target}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800/50 disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-md transition-all flex items-center justify-center"
          >
            {isLoading ? <Spinner className="w-5 h-5" /> : 'Start Scan'}
          </button>
        </CardContent>
      </Card>
      
      {error && (
        <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg mb-6">
            <p className="font-bold">Error</p>
            <p>{error}</p>
        </div>
      )}

      {isLoading && !reconResult && (
        <div className="text-center py-10">
            <Spinner className="w-12 h-12 mx-auto text-blue-500" />
            <p className="mt-4 text-gray-400">AI is analyzing target... This may take a moment.</p>
        </div>
      )}
      
      {reconResult && (
        <Card>
            <CardHeader>
                <h3 className="text-xl font-semibold text-white">Discovered Assets for <span className="text-blue-400">{target}</span></h3>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {reconResult.assets.map((asset, index) => (
                        <AssetCard key={index} asset={asset} />
                    ))}
                </div>
            </CardContent>
        </Card>
      )}

      {!isLoading && !reconResult && (
         <div className="text-center py-10 border-2 border-dashed border-gray-700 rounded-lg">
            <p className="text-gray-500">Scan results will appear here.</p>
         </div>
      )}

    </div>
  );
};

export default ReconPanel;
