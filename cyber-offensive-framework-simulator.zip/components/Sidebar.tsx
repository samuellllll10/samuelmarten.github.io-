
import React from 'react';
import { View } from '../types';
import { TargetIcon, DnaIcon, LinkIcon, GhostIcon, DocumentIcon } from './common/icons';

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void;
  isScanning: boolean;
}

const NavItem = ({ icon, label, view, activeView, setActiveView, isScanning }: { icon: React.ReactNode; label: string; view: View; activeView: View; setActiveView: (view: View) => void; isScanning: boolean; }) => {
  const isActive = activeView === view;
  return (
    <li
      onClick={() => !isScanning && setActiveView(view)}
      className={`flex items-center p-3 my-1 rounded-lg cursor-pointer transition-all duration-200 ${
        isActive
          ? 'bg-blue-600/20 text-blue-300'
          : 'text-gray-400 hover:bg-gray-700/50 hover:text-white'
      } ${isScanning ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {icon}
      <span className="ml-4 font-medium">{label}</span>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, isScanning }) => {
  const menuItems = [
    { view: View.RECON, label: 'Recon & Crawler', icon: <TargetIcon className="w-5 h-5" /> },
    { view: View.PAYLOAD_GENERATOR, label: 'AI Payload Generator', icon: <DnaIcon className="w-5 h-5" /> },
    { view: View.EXPLOIT_CHAINER, label: 'Autonomous Exploiter', icon: <LinkIcon className="w-5 h-5" /> },
    { view: View.STEALTH_SETTINGS, label: 'Stealth AI', icon: <GhostIcon className="w-5 h-5" /> },
    { view: View.POC_GENERATOR, label: 'Auto PoC Generator', icon: <DocumentIcon className="w-5 h-5" /> },
  ];

  return (
    <div className="w-72 bg-gray-900/70 border-r border-gray-800 p-4 flex flex-col backdrop-blur-lg">
      <div className="flex items-center mb-8">
        <div className="w-10 h-10 bg-gradient-to-tr from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
          <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11c0 3.517-1.009 6.789-2.756 9.356m-8.488-9.356c0-4.142 3.358-7.5 7.5-7.5s7.5 3.358 7.5 7.5c0 1.107-.243 2.158-.68 3.124" />
          </svg>
        </div>
        <h1 className="ml-3 text-xl font-bold text-white tracking-wider">CYBERX AI</h1>
      </div>
      <nav>
        <ul>
          {menuItems.map(item => (
            <NavItem key={item.view} {...item} activeView={activeView} setActiveView={setActiveView} isScanning={isScanning} />
          ))}
        </ul>
      </nav>
      <div className="mt-auto p-4 bg-gray-800/50 rounded-lg text-center text-xs text-gray-400">
        <p className="font-semibold text-yellow-400">SIMULATION MODE</p>
        <p className="mt-1">This is an educational tool. All operations are simulated and do not interact with live targets.</p>
      </div>
    </div>
  );
};

export default Sidebar;
