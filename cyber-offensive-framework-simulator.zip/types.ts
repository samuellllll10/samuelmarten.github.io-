
export enum View {
  RECON = 'RECON',
  PAYLOAD_GENERATOR = 'PAYLOAD_GENERATOR',
  EXPLOIT_CHAINER = 'EXPLOIT_CHAINER',
  STEALTH_SETTINGS = 'STEALTH_SETTINGS',
  POC_GENERATOR = 'POC_GENERATOR',
}

export interface ReconAsset {
  type: 'Subdomain' | 'IP Address' | 'API Endpoint' | 'JavaScript File';
  value: string;
  description: string;
}

export interface ReconResult {
  assets: ReconAsset[];
}

export interface GeneratedPayload {
  type: string;
  payload: string;
  description: string;
  effectiveness: number;
}

export interface ExploitStep {
  step: number;
  vulnerability: string;
  description: string;
  impact: string;
}

export interface ExploitChain {
  title: string;
  steps: ExploitStep[];
  final_impact: string;
}

export interface PocReport {
  title: string;
  summary: string;
  steps_to_reproduce: string;
  impact: string;
  recommendation: string;
  curl_command: string;
}
