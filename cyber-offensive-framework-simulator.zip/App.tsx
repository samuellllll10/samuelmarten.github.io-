
import React, { useState, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import ReconPanel from './components/panels/ReconPanel';
import PayloadPanel from './components/panels/PayloadPanel';
import ExploitChainPanel from './components/panels/ExploitChainPanel';
import StealthPanel from './components/panels/StealthPanel';
import PocPanel from './components/panels/PocPanel';
import { View } from './types';
import type { ReconResult, GeneratedPayload, ExploitChain, PocReport, ReconAsset } from './types';
import * as geminiService from './services/geminiService';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.RECON);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // State for each module's data
  const [reconResult, setReconResult] = useState<ReconResult | null>(null);
  const [payloads, setPayloads] = useState<GeneratedPayload[] | null>(null);
  const [exploitChain, setExploitChain] = useState<ExploitChain | null>(null);
  const [pocReport, setPocReport] = useState<PocReport | null>(null);

  const handleApiCall = async <T,>(
    apiCall: () => Promise<T>,
    onSuccess: (data: T) => void,
    resetStates: (()=>void)[] = []
  ) => {
    setIsLoading(true);
    setError(null);
    resetStates.forEach(fn => fn());
    try {
      const result = await apiCall();
      onSuccess(result);
    } catch (e: any) {
      setError(e.message || "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartRecon = useCallback(async (target: string) => {
    await handleApiCall(
        () => geminiService.runReconnaissance(target),
        (data) => setReconResult(data),
        [() => setExploitChain(null), () => setPocReport(null)]
    );
  }, []);

  const handleGeneratePayloads = useCallback(async (vulnType: string, context: string) => {
    await handleApiCall(
        () => geminiService.generatePayload(vulnType, context),
        (data) => setPayloads(data)
    );
  }, []);

  const handleChainExploits = useCallback(async () => {
    if (reconResult) {
      await handleApiCall(
        () => geminiService.chainExploits(reconResult.assets),
        (data) => setExploitChain(data),
        [() => setPocReport(null)]
      );
    } else {
        setError("Reconnaissance data is required to chain exploits.");
    }
  }, [reconResult]);

  const handleGeneratePoc = useCallback(async () => {
    if (reconResult && exploitChain) {
        await handleApiCall(
            () => geminiService.generatePoc(exploitChain, reconResult.assets),
            (data) => setPocReport(data)
        );
    } else {
        setError("Both reconnaissance data and an exploit chain are required to generate a PoC.");
    }
  }, [reconResult, exploitChain]);

  const renderActiveView = () => {
    switch (activeView) {
      case View.RECON:
        return <ReconPanel onStartRecon={handleStartRecon} reconResult={reconResult} isLoading={isLoading} error={error} />;
      case View.PAYLOAD_GENERATOR:
        return <PayloadPanel onGenerate={handleGeneratePayloads} payloads={payloads} isLoading={isLoading} error={error} />;
      case View.EXPLOIT_CHAINER:
        return <ExploitChainPanel onChainExploits={handleChainExploits} exploitChain={exploitChain} reconResult={reconResult} isLoading={isLoading} error={error} />;
      case View.STEALTH_SETTINGS:
        return <StealthPanel />;
      case View.POC_GENERATOR:
        return <PocPanel onGeneratePoc={handleGeneratePoc} pocReport={pocReport} exploitChain={exploitChain} reconResult={reconResult} isLoading={isLoading} error={error} />;
      default:
        return <ReconPanel onStartRecon={handleStartRecon} reconResult={reconResult} isLoading={isLoading} error={error} />;
    }
  };

  return (
    <div className="flex h-screen bg-black text-gray-200 font-sans">
      <Sidebar activeView={activeView} setActiveView={(view) => { setError(null); setActiveView(view)}} isScanning={isLoading} />
      <main className="flex-1 bg-gray-950/50" style={{ backgroundImage: 'radial-gradient(circle at top right, rgba(29, 78, 216, 0.15), transparent 40%), radial-gradient(circle at bottom left, rgba(107, 33, 168, 0.15), transparent 50%)' }}>
        {renderActiveView()}
      </main>
    </div>
  );
};

export default App;
