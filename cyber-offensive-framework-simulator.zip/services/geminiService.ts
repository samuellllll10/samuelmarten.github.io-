
import { GoogleGenAI, Type } from "@google/genai";
import type { ReconResult, GeneratedPayload, ExploitChain, PocReport, ReconAsset } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This is a fallback for development and will be displayed in the UI.
  // In a real deployed environment, the key should be set.
  console.warn("API_KEY environment variable not set. Using a placeholder. App will not be fully functional.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "API_KEY_NOT_SET" });

const reconSchema = {
  type: Type.OBJECT,
  properties: {
    assets: {
      type: Type.ARRAY,
      description: "List of discovered digital assets.",
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING, description: "Type of asset (e.g., Subdomain, API Endpoint)." },
          value: { type: Type.STRING, description: "The value or URL of the asset." },
          description: { type: Type.STRING, description: "Brief description of the asset's potential relevance." },
        },
        required: ["type", "value", "description"],
      },
    },
  },
  required: ["assets"],
};

const payloadSchema = {
    type: Type.ARRAY,
    description: "A list of generated exploit payloads.",
    items: {
        type: Type.OBJECT,
        properties: {
            type: { type: Type.STRING, description: "Vulnerability category (e.g., XSS, SQLi)." },
            payload: { type: Type.STRING, description: "The generated payload string." },
            description: { type: Type.STRING, description: "Explanation of how the payload works and evolves." },
            effectiveness: { type: Type.NUMBER, description: "AI's confidence in the payload's success (0.0 to 1.0)." }
        },
        required: ["type", "payload", "description", "effectiveness"]
    }
};

const exploitChainSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "The title of the exploit chain, e.g., 'Open Redirect + CSRF -> Account Takeover'."},
        steps: {
            type: Type.ARRAY,
            description: "The sequence of steps in the exploit chain.",
            items: {
                type: Type.OBJECT,
                properties: {
                    step: { type: Type.INTEGER, description: "The step number in the chain." },
                    vulnerability: { type: Type.STRING, description: "The vulnerability exploited in this step." },
                    description: { type: Type.STRING, description: "Detailed description of the action taken." },
                    impact: { type: Type.STRING, description: "The immediate result or impact of this step." },
                },
                required: ["step", "vulnerability", "description", "impact"],
            }
        },
        final_impact: { type: Type.STRING, description: "The final outcome and impact of the entire chain." }
    },
    required: ["title", "steps", "final_impact"]
};

const pocReportSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A concise and impactful title for the bug report." },
        summary: { type: Type.STRING, description: "A brief summary of the vulnerability and its impact." },
        steps_to_reproduce: { type: Type.STRING, description: "A detailed, step-by-step guide to reproduce the exploit, formatted with newlines."},
        impact: { type: Type.STRING, description: "A detailed explanation of the business or security impact."},
        recommendation: { type: Type.STRING, description: "Actionable advice for developers to fix the vulnerability."},
        curl_command: { type: Type.STRING, description: "A single-line curl command to demonstrate the vulnerability." }
    },
    required: ["title", "summary", "steps_to_reproduce", "impact", "recommendation", "curl_command"]
}


export const runReconnaissance = async (domain: string): Promise<ReconResult> => {
  if (!API_KEY || API_KEY === "API_KEY_NOT_SET") throw new Error("API Key is not configured.");
  const prompt = `Simulate an advanced reconnaissance scan for the domain "${domain}". Identify potential assets like subdomains (including common and obscure ones like test, dev, api, assets), API endpoints from hypothetical JS file parsing, and associated IP addresses. Present this as a list of digital assets. Be creative and realistic for a bug bounty scenario.`;
  
  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: reconSchema
        }
    });
    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as ReconResult;
  } catch (error) {
    console.error("Error during reconnaissance simulation:", error);
    throw new Error("Failed to simulate reconnaissance. Check console for details.");
  }
};

export const generatePayload = async (vulnType: string, context: string): Promise<GeneratedPayload[]> => {
    if (!API_KEY || API_KEY === "API_KEY_NOT_SET") throw new Error("API Key is not configured.");
    const prompt = `Act as an AI payload generator with a "DNA Evolution" capability. For the vulnerability type "${vulnType}", and based on the following context: "${context}", generate a diverse set of 3-5 creative and adaptive payloads. For each, explain how it works and why it might bypass common filters. The payloads should not be generic; they should seem evolved based on the context. Provide a confidence score for each.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: payloadSchema
            }
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as GeneratedPayload[];
    } catch (error) {
        console.error("Error during payload generation simulation:", error);
        throw new Error("Failed to simulate payload generation.");
    }
};

export const chainExploits = async (assets: ReconAsset[]): Promise<ExploitChain> => {
    if (!API_KEY || API_KEY === "API_KEY_NOT_SET") throw new Error("API Key is not configured.");
    const assetsString = assets.map(a => `${a.type}: ${a.value}`).join(', ');
    const prompt = `Act as an Autonomous Exploiter AI. Given the following discovered assets: [${assetsString}], create a plausible and sophisticated exploit chain. Combine at least two hypothetical low-to-medium severity vulnerabilities to achieve a high-impact outcome like account takeover or RCE. Detail each step of the chain logically.`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: exploitChainSchema
            }
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as ExploitChain;
    } catch (error) {
        console.error("Error during exploit chain simulation:", error);
        throw new Error("Failed to simulate exploit chaining.");
    }
};

export const generatePoc = async (chain: ExploitChain | null, assets: ReconAsset[]): Promise<PocReport> => {
    if (!API_KEY || API_KEY === "API_KEY_NOT_SET") throw new Error("API Key is not configured.");
    if (!chain || assets.length === 0) {
        throw new Error("Cannot generate report without reconnaissance and a chained exploit.");
    }
    const prompt = `Act as an Auto PoC Generator. Based on the following discovered assets and exploit chain, create a professional, detailed Proof of Concept (PoC) report suitable for submission to HackerOne or Bugcrowd.
    
    Assets: ${JSON.stringify(assets)}
    Exploit Chain: ${JSON.stringify(chain)}

    Generate a complete report including a strong title, summary, detailed steps to reproduce (formatted for readability), a thorough impact analysis, and a clear recommendation for fixing the issue. Also include a sample curl command demonstrating a key step of the attack.`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: pocReportSchema
            }
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as PocReport;
    } catch (error) {
        console.error("Error during PoC generation:", error);
        throw new Error("Failed to generate PoC report.");
    }
};
